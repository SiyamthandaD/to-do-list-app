// Toggle between login and register forms
document.getElementById('show-register').addEventListener('click', function (e) {
    e.preventDefault();
    document.getElementById('login-content').style.display = 'none';
    document.getElementById('register-content').style.display = 'block';
    resetForm('login-form');
});

document.getElementById('show-login').addEventListener('click', function (e) {
    e.preventDefault();
    document.getElementById('register-content').style.display = 'none';
    document.getElementById('login-content').style.display = 'block';
    resetForm('register-form');
});

// Password visibility toggle
function setupPasswordToggle(toggleId, inputId) {
    const toggle = document.getElementById(toggleId);
    const input = document.getElementById(inputId);

    toggle.addEventListener('click', function () {
        if (input.type === 'password') {
            input.type = 'text';
            toggle.textContent = '🙈';
            toggle.setAttribute('aria-label', 'Hide password');
        } else {
            input.type = 'password';
            toggle.textContent = '👁️';
            toggle.setAttribute('aria-label', 'Show password');
        }
    });
}

setupPasswordToggle('loginToggle', 'loginPassword');
setupPasswordToggle('registerToggle', 'registerPassword');

// --- Core Authentication Logic ---
const users = JSON.parse(localStorage.getItem('taskmaster_users')) || [];
const loginError = document.getElementById('loginError');
const registerError = document.getElementById('registerError');

// Password strength indicator
document.getElementById('registerPassword')?.addEventListener('input', function (e) {
    const password = e.target.value;
    const strengthMeter = document.getElementById('passwordStrength') || createPasswordStrengthMeter();
    updatePasswordStrength(strengthMeter, password);
});

function createPasswordStrengthMeter() {
    const meter = document.createElement('div');
    meter.id = 'passwordStrength';
    meter.style.height = '4px';
    meter.style.marginTop = '5px';
    meter.style.borderRadius = '2px';
    meter.style.transition = 'all 0.3s ease';
    document.querySelector('.password-wrapper').appendChild(meter);
    return meter;
}

function updatePasswordStrength(meter, password) {
    let strength = 0;
    if (password.length > 0) strength += 1;
    if (password.length >= 8) strength += 1;
    if (password.match(/[A-Z]/)) strength += 1;
    if (password.match(/[0-9]/)) strength += 1;
    if (password.match(/[^A-Za-z0-9]/)) strength += 1;

    const colors = ['#ff5252', '#ff9747', '#ffd166', '#06d6a0', '#118ab2'];
    meter.style.width = `${strength * 20}%`;
    meter.style.backgroundColor = colors[strength - 1] || 'transparent';
}

// Form reset helper
function resetForm(formId) {
    const form = document.getElementById(formId);
    if (form) {
        form.reset();
        const errorElement = formId === 'login-form' ? loginError : registerError;
        errorElement.textContent = '';
        errorElement.style.display = 'none';
    }
}

// Handle Registration
document.getElementById('register-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('registerUsername').value.trim();
    const email = document.getElementById('registerEmail').value.trim().toLowerCase();
    const password = document.getElementById('registerPassword').value;

    // Enhanced validation
    if (!username || username.length < 3) {
        registerError.textContent = 'Username must be at least 3 characters.';
        registerError.style.display = 'block';
        return;
    }

    if (!validateEmail(email)) {
        registerError.textContent = 'Please enter a valid email address.';
        registerError.style.display = 'block';
        return;
    }

    if (password.length < 8) {
        registerError.textContent = 'Password must be at least 8 characters.';
        registerError.style.display = 'block';
        return;
    }

    if (!password.match(/[A-Z]/) || !password.match(/[0-9]/)) {
        registerError.textContent = 'Password must contain at least one number and one uppercase letter.';
        registerError.style.display = 'block';
        return;
    }

    // Check if user already exists
    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
        registerError.textContent = 'This email is already registered.';
        registerError.style.display = 'block';
        return;
    }

    // Create new user
    const newUser = {
        id: Date.now().toString(),
        username: username,
        email: email,
        password: password, // Note: In production, this should be hashed
        createdAt: new Date().toISOString(),
        lastLogin: null
    };

    users.push(newUser);
    localStorage.setItem('taskmaster_users', JSON.stringify(users));
    localStorage.setItem('taskmaster_current_user', JSON.stringify(newUser));

    registerError.textContent = '';
    registerError.style.display = 'none';

    // Show welcome message before redirect
    showWelcomeMessage(username, () => {
        window.location.href = 'taskmaster-app2.html';
    });
});

// Handle Login
document.getElementById('login-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim().toLowerCase();
    const password = document.getElementById('loginPassword').value;

    // Find user
    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
        // Update last login time
        user.lastLogin = new Date().toISOString();
        // Update user in storage
        const updatedUsers = users.map(u => u.id === user.id ? user : u);
        localStorage.setItem('taskmaster_users', JSON.stringify(users));
        localStorage.setItem('taskmaster_current_user', JSON.stringify(user));

        loginError.textContent = '';
        loginError.style.display = 'none';

        // Show welcome back message before redirect
        showWelcomeMessage(user.username, () => {
            window.location.href = 'taskmaster-app2.html';
        });
    } else {
        // Login failed
        loginError.textContent = 'Invalid email or password.';
        loginError.style.display = 'block';

        // Shake animation for error feedback
        loginError.style.animation = 'shake 0.5s';
        setTimeout(() => {
            loginError.style.animation = '';
        }, 500);
    }
});

// Helper functions
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function showWelcomeMessage(username, callback) {
    const welcomeMsg = document.createElement('div');
    welcomeMsg.className = 'welcome-message';
    welcomeMsg.innerHTML = `
        <div class="welcome-content">
            <h3>Welcome${username ? ', ' + username : ''}!</h3>
            <p>Redirecting to your tasks...</p>
        </div>
    `;
    document.body.appendChild(welcomeMsg);

    setTimeout(() => {
        welcomeMsg.classList.add('fade-out');
        setTimeout(callback, 500);
    }, 1500);
}