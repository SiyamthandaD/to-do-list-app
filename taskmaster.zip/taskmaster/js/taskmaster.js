// Task Management with localStorage
let tasks = JSON.parse(localStorage.getItem('taskmaster_tasks')) || [];
let deletedTasks = JSON.parse(localStorage.getItem('taskmaster_deleted_tasks')) || [];
let currentFilter = 'active';
const currentUser = JSON.parse(localStorage.getItem('taskmaster_current_user'));
let notificationTimeouts = [];

// DOM Elements
const navbarToggle = document.getElementById('navbarToggle');
const navbarLinks = document.querySelector('.navbar-links');
const contentSections = document.querySelectorAll('.content-section');
const navLinks = document.querySelectorAll('.nav-link');
const logoutBtn = document.getElementById('logoutBtn');
const taskInput = document.getElementById('taskInput');
const taskDescription = document.getElementById('taskDescription');
const addTaskBtn = document.getElementById('addTaskBtn');
const taskList = document.getElementById('taskList');
const filterBtns = document.querySelectorAll('.filter-btn');
const activeCount = document.getElementById('activeCount');
const completedCount = document.getElementById('completedCount');
const deletedCount = document.getElementById('deletedCount');
const changePasswordBtn = document.getElementById('changePasswordBtn');
const profileUsername = document.getElementById('profileUsername');
const profileEmail = document.getElementById('profileEmail');
const profileJoinDate = document.getElementById('profileJoinDate');
const darkModeToggle = document.getElementById('darkModeToggle');
const themeColorPicker = document.getElementById('themeColorPicker');
const fontFamilySelect = document.getElementById('fontFamilySelect');
const fontSizeRange = document.getElementById('fontSizeRange');
const notificationsToggle = document.getElementById('notificationsToggle');
const defaultViewSelect = document.getElementById('defaultViewSelect');
const tasksCreatedCount = document.getElementById('tasksCreatedCount');
const tasksCompletedCount = document.getElementById('tasksCompletedCount');
const logoutProfileBtn = document.getElementById('logoutProfileBtn');
const deleteAccountBtn = document.getElementById('deleteAccountBtn');
const exportDataBtn = document.getElementById('exportDataBtn');
const importDataBtn = document.getElementById('importDataBtn');
const importDataInput = document.getElementById('importDataInput');
const notificationTimeInput = document.getElementById('notificationTimeInput');
const notificationPopup = document.getElementById('notificationPopup');
const notificationTaskName = document.getElementById('notificationTaskName');
const messagePopup = document.getElementById('messagePopup');
const deleteAccountModal = document.getElementById('deleteAccountModal');
const confirmDeleteInput = document.getElementById('confirmDeleteInput');
const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
const themeBtns = document.querySelectorAll('.theme-btn');
const profilePicture = document.getElementById('profilePicture');
const characterSelectionContainer = document.getElementById('characterSelectionContainer');
const characterAvatars = document.querySelectorAll('.character-avatar');
const changeCharacterBtn = document.getElementById('changeCharacterBtn');


// Functions
const showSection = (sectionId) => {
    contentSections.forEach(section => {
        section.style.display = 'none';
    });
    const section = document.getElementById(sectionId);
    if (section) {
        section.style.display = 'block';
    }
    navLinks.forEach(link => link.classList.remove('active'));
    const activeLink = document.querySelector(`a[href="#${sectionId}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
};

const saveTasks = () => {
    localStorage.setItem('taskmaster_tasks', JSON.stringify(tasks));
    localStorage.setItem('taskmaster_deleted_tasks', JSON.stringify(deletedTasks));
};

const clearAllNotifications = () => {
    notificationTimeouts.forEach(timeout => {
        clearTimeout(timeout.id);
    });
    notificationTimeouts = [];
    console.log("Cleared all pending notifications");
};

const createNotification = (task) => {
    if (!task.notificationTime) {
        console.log("No notification time set for task:", task.title);
        return;
    }

    const timeInMs = task.notificationTime * 60 * 1000;
    console.log(`Creating notification for task: "${task.title}" in ${task.notificationTime} minutes (${timeInMs}ms)`);

    const timeoutId = setTimeout(() => {
        console.log(`Showing notification for task: "${task.title}"`);
        showNotification(task.title);
        notificationTimeouts = notificationTimeouts.filter(t => t.id !== timeoutId);
    }, timeInMs);

    notificationTimeouts.push({
        id: timeoutId,
        taskId: task.id
    });
};

const showNotification = (taskName) => {
    if (notificationsToggle.checked) {
        console.log("Displaying notification for:", taskName);
        notificationTaskName.textContent = taskName;
        notificationPopup.classList.add('visible');
        setTimeout(() => {
            hideNotification();
        }, 5000);
    } else {
        console.log("Notifications are disabled - not showing notification");
    }
};

const hideNotification = () => {
    notificationPopup.classList.remove('visible');
};

const showMessagePopup = () => {
    messagePopup.classList.add('show');
};

const hideMessagePopup = () => {
    messagePopup.classList.remove('show');
};

const showDeleteAccountModal = () => {
    deleteAccountModal.classList.add('show');
};

const hideDeleteAccountModal = () => {
    deleteAccountModal.classList.remove('show');
};

const updateCounts = () => {
    activeCount.textContent = tasks.filter(task => !task.completed).length;
    completedCount.textContent = tasks.filter(task => task.completed).length;
    deletedCount.textContent = deletedTasks.length;
    tasksCreatedCount.textContent = tasks.length + deletedTasks.length;
    tasksCompletedCount.textContent = tasks.filter(task => task.completed).length;
};

const renderTasks = () => {
    taskList.innerHTML = '';
    const filteredTasks = tasks.filter(task => {
        if (currentFilter === 'active') {
            return !task.completed;
        }
        if (currentFilter === 'completed') {
            return task.completed;
        }
        return false;
    });

    if (currentFilter === 'deleted') {
        if (deletedTasks.length === 0) {
            const noTasksMessage = document.createElement('div');
            noTasksMessage.className = 'no-tasks-message';
            noTasksMessage.textContent = 'No deleted tasks.';
            taskList.appendChild(noTasksMessage);
        }
        deletedTasks.forEach(task => {
            const li = document.createElement('li');
            li.className = 'task-item deleted';
            li.innerHTML = `
                <div class="task-info">
                    <div class="task-text-container">
                        <span class="task-title">${task.title}</span>
                        <span class="task-description">${task.description}</span>
                    </div>
                </div>
                <div class="task-actions">
                    <button class="btn secondary-btn restore-btn" data-id="${task.id}">
                        <i class="fas fa-undo"></i>
                    </button>
                    <button class="btn danger-btn delete-btn" data-id="${task.id}">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            `;
            taskList.appendChild(li);
        });
    } else {
        if (filteredTasks.length === 0) {
            const noTasksMessage = document.createElement('div');
            noTasksMessage.className = 'no-tasks-message';
            noTasksMessage.textContent = `No ${currentFilter} tasks.`;
            taskList.appendChild(noTasksMessage);
        }
        filteredTasks.forEach(task => {
            const li = document.createElement('li');
            li.className = `task-item ${task.completed ? 'completed' : ''}`;
            li.innerHTML = `
                <div class="task-info">
                    <input type="checkbox" data-id="${task.id}" ${task.completed ? 'checked' : ''} />
                    <div class="task-text-container">
                        <span class="task-title">${task.title}</span>
                        <span class="task-description">${task.description}</span>
                    </div>
                </div>
                <div class="task-actions">
                    <button class="btn danger-btn move-to-trash-btn" data-id="${task.id}">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            `;
            taskList.appendChild(li);
        });
    }
};

const loadTasks = () => {
    updateCounts();
    renderTasks();
};

const loadProfile = () => {
    if (currentUser) {
        profileUsername.textContent = currentUser.username;
        profileEmail.textContent = currentUser.email;
        profileJoinDate.textContent = new Date(currentUser.createdAt).toLocaleDateString();
        // Add this for last login display
        const lastLoginElement = document.getElementById('lastLoginDate');
        if (currentUser.lastLogin) {
            lastLoginElement.textContent = new Date(currentUser.lastLogin).toLocaleString();
        } else {
            lastLoginElement.textContent = 'First login!';
        }
        updateCounts();

        // Load saved character or show selection
        const savedCharacter = localStorage.getItem('taskmaster_character');
        if (savedCharacter) {
            profilePicture.src = savedCharacter;
            profilePicture.style.display = 'block';
            characterSelectionContainer.style.display = 'none';
        } else {
            profilePicture.style.display = 'none';
            characterSelectionContainer.style.display = 'flex';
        }
    }
};

const setDarkMode = (isEnabled) => {
    document.body.classList.toggle('dark-mode', isEnabled);
    localStorage.setItem('taskmaster_dark_mode', isEnabled);
};

const setTheme = (themeName) => {
    document.body.className = document.body.className.replace(/\btheme-\S+/g, '');
    if (themeName !== 'default') {
        document.body.classList.add(`theme-${themeName}`);
    }
    localStorage.setItem('taskmaster_theme', themeName);
};

const setFontFamily = (fontFamily) => {
    document.body.style.fontFamily = fontFamily;
};

const setFontSize = (fontSize) => {
    document.body.style.fontSize = `${fontSize}px`;
};

const handleExportData = () => {
    const data = {
        tasks: tasks,
        deletedTasks: deletedTasks,
        user: currentUser
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], {
        type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'taskmaster_data.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
};

const handleImportData = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const importedData = JSON.parse(e.target.result);
            if (importedData.tasks && importedData.deletedTasks) {
                tasks = importedData.tasks;
                deletedTasks = importedData.deletedTasks;
                saveTasks();
                loadTasks();
                alert('Data imported successfully!');
            } else {
                alert('Invalid data file format.');
            }
        } catch (error) {
            alert('Failed to parse data file.');
            console.error('Import error:', error);
        }
    };
    reader.readAsText(file);
};

// Event Listeners
navbarToggle.addEventListener('click', () => {
    navbarLinks.classList.toggle('active');
});

navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const sectionId = link.getAttribute('href').substring(1);
        showSection(sectionId);
    });
});

logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('taskmaster_current_user');
    window.location.href = 'index2.html';
});

logoutProfileBtn.addEventListener('click', () => {
    localStorage.removeItem('taskmaster_current_user');
    window.location.href = 'index2.html';
});

addTaskBtn.addEventListener('click', () => {
    const title = taskInput.value.trim();
    const description = taskDescription.value.trim();
    const notificationTime = parseInt(notificationTimeInput.value) || 1;

    if (title) {
        const newTask = {
            id: Date.now(),
            title: title,
            description: description,
            completed: false,
            notificationTime: notificationTime
        };
        console.log("Creating new task with notification in", notificationTime, "minutes");
        tasks.push(newTask);
        saveTasks();
        loadTasks();
        taskInput.value = '';
        taskDescription.value = '';
        notificationTimeInput.value = '';
        if (notificationsToggle.checked) {
            createNotification(newTask);
        }
    }
});

taskList.addEventListener('click', (e) => {
    if (e.target.matches('input[type="checkbox"]')) {
        const taskId = parseInt(e.target.dataset.id);
        const task = tasks.find(t => t.id === taskId);
        if (task) {
            task.completed = e.target.checked;
            saveTasks();
            loadTasks();
        }
    }
    if (e.target.closest('.move-to-trash-btn')) {
        const button = e.target.closest('.move-to-trash-btn');
        const taskId = parseInt(button.dataset.id);
        const taskIndex = tasks.findIndex(t => t.id === taskId);
        if (taskIndex > -1) {
            const taskToMove = tasks.splice(taskIndex, 1)[0];
            deletedTasks.push(taskToMove);
            saveTasks();
            loadTasks();
        }
    }
    if (e.target.closest('.restore-btn')) {
        const button = e.target.closest('.restore-btn');
        const taskId = parseInt(button.dataset.id);
        const taskIndex = deletedTasks.findIndex(t => t.id === taskId);
        if (taskIndex > -1) {
            const taskToRestore = deletedTasks.splice(taskIndex, 1)[0];
            taskToRestore.completed = false;
            tasks.push(taskToRestore);
            saveTasks();
            loadTasks();
        }
    }
    if (e.target.closest('.delete-btn')) {
        const button = e.target.closest('.delete-btn');
        const taskId = parseInt(button.dataset.id);
        deletedTasks = deletedTasks.filter(t => t.id !== taskId);
        saveTasks();
        loadTasks();
    }
});

filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentFilter = btn.dataset.filter;
        renderTasks();
        updateCounts();
    });
});

changePasswordBtn.addEventListener('click', showMessagePopup);

deleteAccountBtn.addEventListener('click', showDeleteAccountModal);

confirmDeleteInput.addEventListener('input', (e) => {
    if (e.target.value === 'DELETE') {
        confirmDeleteBtn.disabled = false;
    } else {
        confirmDeleteBtn.disabled = true;
    }
});

confirmDeleteBtn.addEventListener('click', () => {
    localStorage.clear();
    window.location.href = 'index2.html';
});

darkModeToggle.addEventListener('change', (e) => {
    setDarkMode(e.target.checked);
});

themeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const theme = btn.dataset.theme;
        setTheme(theme);
    });
});

fontFamilySelect.addEventListener('change', (e) => {
    setFontFamily(e.target.value);
    localStorage.setItem('taskmaster_font_family', e.target.value);
});

fontSizeRange.addEventListener('input', (e) => {
    setFontSize(e.target.value);
});

fontSizeRange.addEventListener('change', (e) => {
    localStorage.setItem('taskmaster_font_size', e.target.value);
});

notificationsToggle.addEventListener('change', (e) => {
    if (!e.target.checked) {
        clearAllNotifications();
    }
    localStorage.setItem('taskmaster_notifications', e.target.checked);
    console.log("Notifications toggled:", e.target.checked ? "ON" : "OFF");
});

defaultViewSelect.addEventListener('change', (e) => {
    const newDefaultView = e.target.value;
    localStorage.setItem('taskmaster_default_view', newDefaultView);
    currentFilter = newDefaultView;
    filterBtns.forEach(btn => btn.classList.remove('active'));
    const defaultBtn = document.querySelector(`[data-filter="${newDefaultView}"]`);
    if (defaultBtn) {
        defaultBtn.classList.add('active');
    }
    renderTasks();
    updateCounts();
});

exportDataBtn.addEventListener('click', handleExportData);

importDataBtn.addEventListener('click', () => {
    importDataInput.click();
});

importDataInput.addEventListener('change', handleImportData);

characterAvatars.forEach(avatar => {
    avatar.addEventListener('click', () => {
        const characterSrc = avatar.src;
        profilePicture.src = characterSrc;
        localStorage.setItem('taskmaster_character', characterSrc);
        profilePicture.style.display = 'block';
        characterSelectionContainer.style.display = 'none';
    });
});

changeCharacterBtn.addEventListener('click', () => {
    profilePicture.style.display = 'none';
    characterSelectionContainer.style.display = 'flex';
});

// Initial Load
document.addEventListener('DOMContentLoaded', () => {
    const user = localStorage.getItem('taskmaster_current_user');
    if (!user) {
        window.location.href = 'index2.html';
    } else {
        // Apply saved settings
        const savedTheme = localStorage.getItem('taskmaster_theme') || 'default';
        setTheme(savedTheme);
        const savedDarkMode = JSON.parse(localStorage.getItem('taskmaster_dark_mode'));
        if (savedDarkMode !== null) {
            setDarkMode(savedDarkMode);
            darkModeToggle.checked = savedDarkMode;
        }

        const savedFontFamily = localStorage.getItem('taskmaster_font_family');
        if (savedFontFamily) {
            setFontFamily(savedFontFamily);
            fontFamilySelect.value = savedFontFamily;
        }

        const savedFontSize = localStorage.getItem('taskmaster_font_size');
        if (savedFontSize) {
            setFontSize(savedFontSize);
            fontSizeRange.value = savedFontSize;
        }

        const savedNotifications = localStorage.getItem('taskmaster_notifications');
        if (savedNotifications !== null) {
            notificationsToggle.checked = JSON.parse(savedNotifications);
        }

        const savedDefaultView = localStorage.getItem('taskmaster_default_view');
        if (savedDefaultView) {
            defaultViewSelect.value = savedDefaultView;
            currentFilter = savedDefaultView;
            filterBtns.forEach(btn => btn.classList.remove('active'));
            const defaultBtn = document.querySelector(`[data-filter="${savedDefaultView}"]`);
            if (defaultBtn) {
                defaultBtn.classList.add('active');
            }
        }

        showSection('tasks');
        loadTasks();
        loadProfile();

        console.log("Initial notification setting:", notificationsToggle.checked ? "ON" : "OFF");
    }
});